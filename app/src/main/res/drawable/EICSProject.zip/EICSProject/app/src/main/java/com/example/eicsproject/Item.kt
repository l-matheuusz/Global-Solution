package com.example.eicsproject

data class Item(
    var id: String = "",
    val nome: String = "",
    val descricao: String = "",
    val consumo: Double = 0.0
)
